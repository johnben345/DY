import utils

elc_config_endpoint = 'YOUR_ELASTICACHE_MEMCACHE_ENDPOINT'
memcache_client = utils.set_memcache_client(elc_config_endpoint)

def lambda_handler(event, context):
    try:
        counter = memcache_client.get('counter')
        curr_counter = utils.bytestr_to_int(counter)
        print(f'Counter: {curr_counter}')
        timestamp = memcache_client.get('timestamp')
        if curr_counter == 0:
            print(f'Sending Email: The cat was fed at {timestamp}')
        elif curr_counter > 0 and curr_counter < 15:
            print(f'The cat was last fed at {timestamp}')
        elif curr_counter == 15:
            print(f'Sending Email: The cat was not fed for 15 minutes. since {timestamp}')
        elif curr_counter > 15:
            print(f'The cat has not eaten since {timestamp}')
        
        memcache_client.incr('counter', 1)
    except(AttributeError):
        print(f'Could not get counter from memcache')