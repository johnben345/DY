import sys
import socket
import elasticache_auto_discovery
from pymemcache.client.hash import HashClient


def set_memcache_client(endpoint):
    try:
        nodes = elasticache_auto_discovery.discover(endpoint)
        nodes = map(lambda x: (x[1], int(x[2])), nodes)
        return HashClient(nodes)
    except(Exception):
        print(f'Sending Email: Could not establish connection to memcache')


def bytestr_to_int(bytestr):
    bytestr_as_str = f"{bytestr}"
    bytestr_splited = bytestr_as_str.split("'")
    bytestr_as_int = int(bytestr_splited[1])
    
    return bytestr_as_int