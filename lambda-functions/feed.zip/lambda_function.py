import utils
import urllib.parse

s3_bucket = 'YOUR_S3_BUCKET'
region = 'YOUR_REGION'
elc_config_endpoint = 'YOUR_ELASTICACHE_MEMCACHE_ENDPOINT'


def lambda_handler(event, context):
    # Grab the image from S3
	image = event['Records'][0]['s3']['bucket']['name']
	key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
	
	try:
		for label in utils.detect_labels(s3_bucket, key, region):
			if label['Name'] == 'Milk' or label['Name'] == 'Bread' or label['Name'] == 'Fish':
				to_be_fed = label['Name']
				utils.commit_counter(elc_config_endpoint)
				break
			else:
				to_be_fed = 'nothing'
	
		print(f'The cat was fed {to_be_fed}')
	except(TypeError):
		print(f'Could not process image to verify food type')
