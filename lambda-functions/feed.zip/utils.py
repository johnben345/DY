import boto3
import time
import datetime
import sys
import socket
import elasticache_auto_discovery
from pymemcache.client.hash import HashClient


def commit_counter(endpoint):
    memcache_client = set_memcache_client(endpoint)
    sse = time.time()
    timestamp = datetime.datetime.fromtimestamp(sse).strftime('%Y-%m-%d %H:%M:%S')
    try:
    	memcache_client.set('timestamp', timestamp)
    	memcache_client.set('counter', 0)
    except(AttributeError):
    	print('Could not commit couter to memcache')


def set_memcache_client(endpoint):
    try:
    	nodes = elasticache_auto_discovery.discover(endpoint)
    	nodes = map(lambda x: (x[1], int(x[2])), nodes)
    	return HashClient(nodes)
    except(Exception):
    	print(f'Sending Email: Could not establish connection to memcache')


def detect_labels(bucket, key, region, max_labels=10, min_confidence=90):
	try:
		rekognition = boto3.client('rekognition', region)
		response = rekognition.detect_labels(
			Image={
				"S3Object": {
					"Bucket": bucket,
					"Name": key,
				}
			},
			MaxLabels=max_labels,
			MinConfidence=min_confidence,
		)
	
		return response['Labels']
	except rekognition.exceptions.InvalidS3ObjectException:
		print('Sending Email: Unable to get S3 object, make sure the bucket parameters are set correctly')